# Dino Survival (NeoForge 1.21.1)

Mod de dinosaurios domesticables. Incluye un dinosaurio, el **Raptor**, con diseño, modelo y textura propios.

## Qué hace

- **Domesticar:** da carne cruda (res, cerdo, pollo, cordero o conejo) a un raptor salvaje. Cada pieza sube el progreso de domesticación (se muestra en la barra de acciones). Si dejas de alimentarlo, el progreso baja.
- **Niveles:** cada raptor nace con nivel 1-30. El nivel sube su salud, daño y velocidad, y también su tamaño.
- **Experiencia:** un raptor domesticado gana XP al matar criaturas y sube de nivel.
- **Silla y monturas:** usa una silla (`Saddle`) sobre un raptor tuyo y haz clic derecho para montarlo.
- **Quedarse / seguir:** clic derecho (con la mano vacía y sin silla, o agachado) para sentarlo o hacer que te siga.
- **Cría:** dos raptores domesticados con carne cruda crían una cría que hereda parte del nivel.
- **Curar:** dale carne cruda a un raptor herido.
- **Aparición:** sabanas, junglas, bosques y llanuras. También está el huevo generador en la pestaña creativa **Dino Survival**.

## Cómo compilarlo

Necesitas **JDK 21**.

1. Abre la carpeta en IntelliJ IDEA (importa el proyecto Gradle) o usa la terminal.
2. Si no tienes el wrapper de Gradle: `gradle wrapper --gradle-version 8.10.2`
3. Probar en el juego: `./gradlew runClient`
4. Generar el `.jar`: `./gradlew build` (queda en `build/libs/`). Ponlo en la carpeta `mods` de NeoForge 1.21.1.

Si Gradle no encuentra la versión de NeoForge, cambia `neo_version` en `gradle.properties` por una 21.1.x que exista.

## Estructura

- `entity/Raptor.java` - toda la lógica (domesticación, niveles, cría, montura).
- `client/` - modelo, renderer y capa de silla.
- `registry/` - entidad, ítems y pestaña creativa.
- `resources/` - textura (64x64), idiomas (es/en), aparición en biomas, botín.

## Para añadir otro dinosaurio

Copia `Raptor`, `RaptorModel`, `RaptorRenderer` y la textura, cámbiales el nombre y registra la nueva entidad en `ModEntities`.
