package com.dinosurvival;

import com.dinosurvival.registry.ModCreativeTabs;
import com.dinosurvival.registry.ModEntities;
import com.dinosurvival.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(DinoSurvival.MOD_ID)
public class DinoSurvival {
    public static final String MOD_ID = "dinosurvival";

    public DinoSurvival(IEventBus modEventBus) {
        ModEntities.ENTITIES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModCreativeTabs.TABS.register(modEventBus);
    }
}
