package com.dinosurvival.client;

import com.dinosurvival.DinoSurvival;
import com.dinosurvival.entity.Raptor;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class RaptorModel extends EntityModel<Raptor> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(DinoSurvival.MOD_ID, "raptor"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart tail;
    private final ModelPart tail2;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;
    private final ModelPart rightArm;
    private final ModelPart leftArm;

    public RaptorModel(ModelPart root) {
        super(RenderType::entityCutoutNoCull);
        this.root = root;
        this.head = root.getChild("head");
        this.tail = root.getChild("tail");
        this.tail2 = this.tail.getChild("tail2");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition parts = mesh.getRoot();

        parts.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -4.0F, -7.0F, 6.0F, 7.0F, 14.0F),
                PartPose.offset(0.0F, 13.0F, 0.0F));

        parts.addOrReplaceChild("neck",
                CubeListBuilder.create().texOffs(0, 22).addBox(-2.0F, -8.0F, -2.0F, 4.0F, 9.0F, 4.0F),
                PartPose.offset(0.0F, 11.0F, -6.0F));

        parts.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 36).addBox(-2.5F, -3.0F, -7.0F, 5.0F, 5.0F, 8.0F),
                PartPose.offset(0.0F, 5.0F, -6.0F));

        PartDefinition tail = parts.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(18, 22).addBox(-2.0F, -2.0F, 0.0F, 4.0F, 4.0F, 10.0F),
                PartPose.offset(0.0F, 11.0F, 7.0F));
        tail.addOrReplaceChild("tail2",
                CubeListBuilder.create().texOffs(28, 36).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 8.0F),
                PartPose.offset(0.0F, 0.0F, 10.0F));

        CubeListBuilder leg = CubeListBuilder.create().texOffs(0, 50).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 10.0F, 3.0F);
        parts.addOrReplaceChild("right_leg", leg, PartPose.offset(-2.5F, 14.0F, 3.0F));
        parts.addOrReplaceChild("left_leg", leg, PartPose.offset(2.5F, 14.0F, 3.0F));

        CubeListBuilder arm = CubeListBuilder.create().texOffs(14, 50).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F);
        parts.addOrReplaceChild("right_arm", arm, PartPose.offset(-3.5F, 12.0F, -5.0F));
        parts.addOrReplaceChild("left_arm", arm, PartPose.offset(3.5F, 12.0F, -5.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(Raptor entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        head.xRot = headPitch * Mth.DEG_TO_RAD;

        float swing = limbSwing * 0.7F;
        rightLeg.xRot = Mth.cos(swing) * 1.2F * limbSwingAmount;
        leftLeg.xRot = Mth.cos(swing + Mth.PI) * 1.2F * limbSwingAmount;
        rightArm.xRot = Mth.cos(swing + Mth.PI) * 0.6F * limbSwingAmount;
        leftArm.xRot = Mth.cos(swing) * 0.6F * limbSwingAmount;

        tail.yRot = Mth.cos(ageInTicks * 0.1F) * 0.1F + Mth.cos(swing) * 0.25F * limbSwingAmount;
        tail2.yRot = Mth.cos(ageInTicks * 0.1F - 0.8F) * 0.15F;

        if (entity.isInSittingPose()) {
            root.y = 4.0F;
            rightLeg.xRot = -1.3F;
            leftLeg.xRot = -1.3F;
        } else {
            root.y = 0.0F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        root.render(poseStack, buffer, packedLight, packedOverlay, color);
    }
}
