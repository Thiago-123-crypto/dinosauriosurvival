package com.dinosurvival.client;

import com.dinosurvival.DinoSurvival;
import com.dinosurvival.entity.Raptor;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class RaptorRenderer extends MobRenderer<Raptor, RaptorModel> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(DinoSurvival.MOD_ID, "textures/entity/raptor.png");

    public RaptorRenderer(EntityRendererProvider.Context context) {
        super(context, new RaptorModel(context.bakeLayer(RaptorModel.LAYER_LOCATION)), 0.7F);
        addLayer(new RaptorSaddleLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(Raptor entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(Raptor entity, PoseStack poseStack, float partialTick) {
        // Los dinosaurios de mayor nivel se ven un poco mas grandes.
        float scale = 0.9F + entity.getDinoLevel() * 0.004F;
        if (entity.isBaby()) {
            scale *= 0.5F;
        }
        poseStack.scale(scale, scale, scale);
    }
}
