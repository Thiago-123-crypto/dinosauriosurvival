package com.dinosurvival.client;

import com.dinosurvival.DinoSurvival;
import com.dinosurvival.entity.Raptor;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;

public class RaptorSaddleLayer extends RenderLayer<Raptor, RaptorModel> {
    private static final ResourceLocation SADDLE_TEXTURE =
            ResourceLocation.fromNamespaceAndPath(DinoSurvival.MOD_ID, "textures/entity/raptor_saddle.png");

    public RaptorSaddleLayer(RenderLayerParent<Raptor, RaptorModel> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, Raptor entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (!entity.isSaddled()) {
            return;
        }
        renderColoredCutoutModel(getParentModel(), SADDLE_TEXTURE, poseStack, buffer, packedLight, entity, -1);
    }
}
