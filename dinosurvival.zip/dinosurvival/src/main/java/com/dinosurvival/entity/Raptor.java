package com.dinosurvival.entity;

import com.dinosurvival.registry.ModEntities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Rabbit;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Raptor: dinosaurio domesticable con nivel, estadisticas, experiencia, cria y montura.
 */
public class Raptor extends TamableAnimal {
    public static final int MAX_LEVEL = 100;

    private static final EntityDataAccessor<Integer> DATA_LEVEL =
            SynchedEntityData.defineId(Raptor.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_SADDLED =
            SynchedEntityData.defineId(Raptor.class, EntityDataSerializers.BOOLEAN);

    private static final Ingredient RAW_FOOD = Ingredient.of(
            Items.BEEF, Items.PORKCHOP, Items.CHICKEN, Items.MUTTON, Items.RABBIT);

    private static final double BASE_HEALTH = 30.0D;
    private static final double BASE_DAMAGE = 5.0D;
    private static final double BASE_SPEED = 0.30D;

    private int tamingProgress;
    private int lastFeedTick;
    private int xp;

    public Raptor(EntityType<? extends Raptor> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, BASE_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, BASE_SPEED)
                .add(Attributes.ATTACK_DAMAGE, BASE_DAMAGE)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    // ------------------------------------------------------------------ datos

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_LEVEL, 1);
        builder.define(DATA_SADDLED, false);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("DinoLevel", getDinoLevel());
        tag.putInt("DinoXp", xp);
        tag.putBoolean("Saddled", isSaddled());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("DinoLevel")) {
            entityData.set(DATA_LEVEL, Mth.clamp(tag.getInt("DinoLevel"), 1, MAX_LEVEL));
        }
        xp = tag.getInt("DinoXp");
        setSaddled(tag.getBoolean("Saddled"));
        applyLevelStats();
    }

    public int getDinoLevel() {
        return entityData.get(DATA_LEVEL);
    }

    public void setDinoLevel(int newLevel) {
        entityData.set(DATA_LEVEL, Mth.clamp(newLevel, 1, MAX_LEVEL));
        applyLevelStats();
    }

    public boolean isSaddled() {
        return entityData.get(DATA_SADDLED);
    }

    public void setSaddled(boolean saddled) {
        entityData.set(DATA_SADDLED, saddled);
    }

    /** Las estadisticas crecen con el nivel (solo en servidor; el cliente las recibe sincronizadas). */
    private void applyLevelStats() {
        if (level().isClientSide) {
            return;
        }
        int extra = getDinoLevel() - 1;
        setBase(Attributes.MAX_HEALTH, BASE_HEALTH + extra * 2.0D);
        setBase(Attributes.ATTACK_DAMAGE, BASE_DAMAGE * (1.0D + extra * 0.03D));
        setBase(Attributes.MOVEMENT_SPEED, BASE_SPEED * (1.0D + extra * 0.004D));
    }

    private void setBase(net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> attribute, double value) {
        AttributeInstance instance = getAttribute(attribute);
        if (instance != null) {
            instance.setBaseValue(value);
        }
    }

    // ------------------------------------------------------------------ IA

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new FloatGoal(this));
        goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.3D, true));
        goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.2D, 10.0F, 2.0F));
        goalSelector.addGoal(5, new BreedGoal(this, 1.0D));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        targetSelector.addGoal(3, new HurtByTargetGoal(this).setAlertOthers());
        targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Animal.class, 10, true, false,
                target -> !isTame() && (target instanceof Chicken || target instanceof Rabbit)));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        // El progreso de domesticacion se pierde poco a poco si dejas de alimentarlo.
        if (!level().isClientSide && !isTame() && tamingProgress > 0
                && tickCount - lastFeedTick > 600 && tickCount % 40 == 0) {
            tamingProgress = Math.max(0, tamingProgress - 2);
        }
    }

    // ------------------------------------------------------------------ spawn

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor levelAccessor, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData) {
        SpawnGroupData data = super.finalizeSpawn(levelAccessor, difficulty, spawnType, spawnGroupData);
        setDinoLevel(1 + levelAccessor.getRandom().nextInt(30));
        setHealth(getMaxHealth());
        return data;
    }

    // ------------------------------------------------------------------ interaccion

    @Override
    public boolean isFood(ItemStack stack) {
        return RAW_FOOD.test(stack);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!isTame()) {
            if (isFood(stack)) {
                if (!level().isClientSide) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    tamingProgress = Math.min(100, tamingProgress + 10 + random.nextInt(16));
                    lastFeedTick = tickCount;
                    if (tamingProgress >= 100) {
                        tame(player);
                        navigation.stop();
                        setTarget(null);
                        setOrderedToSit(false);
                        setDinoLevel(getDinoLevel() + 1 + random.nextInt(6));
                        setHealth(getMaxHealth());
                        level().broadcastEntityEvent(this, (byte) 7);
                        player.displayClientMessage(Component.translatable("message.dinosurvival.tamed", getDinoLevel()), true);
                    } else {
                        level().broadcastEntityEvent(this, (byte) 6);
                        player.displayClientMessage(
                                Component.translatable("message.dinosurvival.taming_progress", tamingProgress), true);
                    }
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            if (stack.isEmpty()) {
                if (!level().isClientSide) {
                    player.displayClientMessage(Component.translatable("message.dinosurvival.wild_info",
                            getDinoLevel(), tamingProgress), true);
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            return InteractionResult.PASS;
        }

        if (!isOwnedBy(player)) {
            return InteractionResult.PASS;
        }

        if (stack.is(Items.SADDLE) && !isSaddled() && !isBaby()) {
            if (!level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                setSaddled(true);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        if (isFood(stack)) {
            if (getHealth() < getMaxHealth()) {
                if (!level().isClientSide) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    heal(6.0F);
                    level().broadcastEntityEvent(this, (byte) 7);
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            return super.mobInteract(player, hand); // cria con comida
        }

        if (isSaddled() && !isBaby() && !player.isSecondaryUseActive() && !isVehicle()) {
            if (!level().isClientSide) {
                setOrderedToSit(false);
                player.startRiding(this);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        if (!level().isClientSide) {
            setOrderedToSit(!isOrderedToSit());
            navigation.stop();
            setTarget(null);
            player.displayClientMessage(Component.translatable("message.dinosurvival.info",
                    getDinoLevel(), Mth.ceil(getHealth()), Mth.ceil(getMaxHealth()),
                    Mth.floor(getAttributeValue(Attributes.ATTACK_DAMAGE)), xp, xpForNextLevel()), true);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    // ------------------------------------------------------------------ experiencia

    public int xpForNextLevel() {
        return 10 + getDinoLevel() * 5;
    }

    public void addXp(int amount) {
        if (!isTame() || level().isClientSide) {
            return;
        }
        xp += amount;
        boolean leveledUp = false;
        while (getDinoLevel() < MAX_LEVEL && xp >= xpForNextLevel()) {
            xp -= xpForNextLevel();
            entityData.set(DATA_LEVEL, getDinoLevel() + 1);
            leveledUp = true;
        }
        if (leveledUp) {
            applyLevelStats();
            setHealth(getMaxHealth());
            level().broadcastEntityEvent(this, (byte) 7);
            if (getOwner() instanceof Player owner) {
                owner.displayClientMessage(
                        Component.translatable("message.dinosurvival.level_up", getDinoLevel()), true);
            }
        }
    }

    // ------------------------------------------------------------------ cria

    @Override
    public boolean canMate(Animal other) {
        if (other == this || !(other instanceof Raptor partner)) {
            return false;
        }
        if (!isTame() || !partner.isTame() || isInSittingPose() || partner.isInSittingPose()) {
            return false;
        }
        return isInLove() && partner.isInLove();
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel serverLevel, AgeableMob otherParent) {
        Raptor baby = ModEntities.RAPTOR.get().create(serverLevel);
        if (baby != null) {
            UUID ownerId = getOwnerUUID();
            if (ownerId != null) {
                baby.setOwnerUUID(ownerId);
                baby.setTame(true, true);
            }
            int parentLevel = otherParent instanceof Raptor r ? Math.max(getDinoLevel(), r.getDinoLevel()) : getDinoLevel();
            baby.setDinoLevel(Math.max(1, parentLevel / 2 + random.nextInt(5)));
            baby.setHealth(baby.getMaxHealth());
        }
        return baby;
    }

    // ------------------------------------------------------------------ montura

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        if (isSaddled() && getFirstPassenger() instanceof Player player) {
            return player;
        }
        return super.getControllingPassenger();
    }

    @Override
    protected void tickRidden(Player player, Vec3 travelVector) {
        super.tickRidden(player, travelVector);
        setRot(player.getYRot(), player.getXRot() * 0.5F);
        yRotO = yBodyRot = yHeadRot = getYRot();
    }

    @Override
    protected Vec3 getRiddenInput(Player player, Vec3 travelVector) {
        float strafe = player.xxa * 0.5F;
        float forward = player.zza;
        if (forward <= 0.0F) {
            forward *= 0.25F;
        }
        return new Vec3(strafe, 0.0D, forward);
    }

    @Override
    protected float getRiddenSpeed(Player player) {
        return (float) getAttributeValue(Attributes.MOVEMENT_SPEED);
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel serverLevel, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(serverLevel, source, recentlyHit);
        if (isSaddled()) {
            spawnAtLocation(Items.SADDLE);
        }
    }

    // ------------------------------------------------------------------ sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.FOX_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.FOX_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.FOX_DEATH;
    }
}
