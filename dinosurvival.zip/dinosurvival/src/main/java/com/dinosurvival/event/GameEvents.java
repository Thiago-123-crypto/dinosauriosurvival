package com.dinosurvival.event;

import com.dinosurvival.DinoSurvival;
import com.dinosurvival.entity.Raptor;
import net.minecraft.util.Mth;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

@EventBusSubscriber(modid = DinoSurvival.MOD_ID)
public class GameEvents {

    /** Un raptor domesticado gana experiencia al matar criaturas. */
    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getSource().getEntity() instanceof Raptor raptor && raptor.isTame()) {
            raptor.addXp(Math.max(2, Mth.floor(event.getEntity().getMaxHealth() / 2.0F)));
        }
    }
}
