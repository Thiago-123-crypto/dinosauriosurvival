package com.dinosurvival.registry;

import com.dinosurvival.DinoSurvival;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DinoSurvival.MOD_ID);

    public static final Supplier<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.dinosurvival.main"))
                    .icon(() -> new ItemStack(ModItems.RAPTOR_SPAWN_EGG.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.RAPTOR_SPAWN_EGG.get());
                        output.accept(Items.SADDLE);
                    })
                    .build());
}
