package com.dinosurvival.registry;

import com.dinosurvival.DinoSurvival;
import com.dinosurvival.entity.Raptor;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, DinoSurvival.MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<Raptor>> RAPTOR = ENTITIES.register("raptor",
            () -> EntityType.Builder.of(Raptor::new, MobCategory.CREATURE)
                    .sized(0.9F, 1.5F)
                    .passengerAttachments(1.15F)
                    .clientTrackingRange(10)
                    .build("raptor"));
}
