package com.dinosurvival.registry;

import com.dinosurvival.DinoSurvival;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(DinoSurvival.MOD_ID);

    public static final DeferredItem<Item> RAPTOR_SPAWN_EGG = ITEMS.register("raptor_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.RAPTOR, 0x5B7A46, 0xC9A44C, new Item.Properties()));
}
